<%@page contentType="text/html" pageEncoding="UTF-8" import="java.sql.*"%>
<%@ include file="dbConnect.jsp" %>
<%
    String role = (String) session.getAttribute("userRole");
    if(role == null || !role.equalsIgnoreCase("Admin")) {
        response.sendRedirect("index.jsp");
        return;
    }

    // ফর্ম থেকে আসা ডেটা সংগ্রহ
    String teacherID = request.getParameter("teacherID");
    String newPassword = request.getParameter("password");
    String newName = request.getParameter("name");
    String newPhone = request.getParameter("phone");
    String newAddress = request.getParameter("address");

    boolean isUpdated = false;
    String errorMsg = "";

    if(conn != null && teacherID != null && !teacherID.trim().isEmpty()) {
        PreparedStatement pstUser = null;
        
        try {
            conn.setAutoCommit(false); 

            // Users টেবিলের তথ্য আপডেট (Name, Phone, Address সহ)
            String sqlUser = "UPDATE Users SET Password = ?, Name = ?, Phone = ?, Address = ? WHERE UPPER(TRIM(User_ID)) = UPPER(TRIM(?))";
            pstUser = conn.prepareStatement(sqlUser);
            pstUser.setString(1, newPassword != null ? newPassword.trim() : "");
            pstUser.setString(2, newName != null ? newName.trim() : "");
            pstUser.setString(3, newPhone != null ? newPhone.trim() : "");
            pstUser.setString(4, newAddress != null ? newAddress.trim() : "");
            pstUser.setString(5, teacherID.trim());
            
            int userRows = pstUser.executeUpdate();

            if(userRows > 0) {
                conn.commit(); 
                isUpdated = true;
            } else {
                conn.rollback();
                errorMsg = "Teacher ID '" + teacherID.trim() + "' not found.";
            }
        } catch(Exception e) {
            try { conn.rollback(); } catch(SQLException ex) {}
            errorMsg = "Database Error: " + e.getMessage();
        } finally {
            if(pstUser != null) { try { pstUser.close(); } catch(SQLException ex) {} }
            try { conn.setAutoCommit(true); } catch(SQLException ex) {}
        }
    } else {
        errorMsg = "Invalid Request: Teacher ID is missing.";
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Updating Teacher...</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #020617; color: #fff; font-family: 'Poppins', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .status-card { background: rgba(30, 41, 59, 0.5); backdrop-filter: blur(20px); padding: 40px; border-radius: 30px; text-align: center; width: 480px; border: 1px solid <%= isUpdated ? "rgba(16, 185, 129, 0.3)" : "rgba(239, 68, 68, 0.3)" %>; }
        .icon-box { width: 80px; height: 80px; margin: 0 auto 20px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 2.5rem; color: <%= isUpdated ? "#10b981" : "#f87171" %>; }
    </style>
</head>
<body>
    <div class="status-card">
        <div class="icon-box"><i class="fas <%= isUpdated ? "fa-check-circle" : "fa-times-circle" %>"></i></div>
        <% if(isUpdated) { %>
            <h2>Update Success!</h2>
            <p>Teacher (<b><%= teacherID %></b>) details updated successfully.</p>
        <% } else { %>
            <h2>Update Failed</h2>
            <p style="color: #f87171;"><%= errorMsg %></p>
        <% } %>
    </div>
    <script>
        setTimeout(() => {
            window.location.href = "manageTeachers.jsp";
        }, 2000);
    </script>
</body>
</html>
<%
    if (conn != null && !conn.isClosed()) {
        conn.close();
    }
%>